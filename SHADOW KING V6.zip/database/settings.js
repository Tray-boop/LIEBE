// Module
const fs = require('fs')

//Bot Settings
global.connect = true // True For Pairing // False For Qr
global.publicX = true // True For Public // False For Self
global.owner = ['6288708842827'] //Own Number
global.developer = "RuszNotDev" //Dev Name
global.botname = "Shadow King" //Bot Name
global.version = "Free" //Version Bot

//Sticker Setiings
global.packname = "Sticker By" //Pack Name 
global.author = "Bot" // Author

//Social Media Settings
global.ytube = "https://youtube.com/"
global.ttok = ""
global.igram = "https://instagram.com/"
global.chtele = ""
global.tgram = "https://t.me/"
global.limitCount = 1,

global.mess = {
 owner: '*Khusus Bang Rusz*',
 premium: '*Khusus Bang Rusz*'
}

//System Bot Settings
global.prefa = ['','!','.',',','🐤','🗿'] // Prefix // Not Change

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})